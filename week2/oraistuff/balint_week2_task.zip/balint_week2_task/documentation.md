# Documentation for week 2 task - Triggering different status codes using requests
# By Bálint Maróti
# Requirements
- Python 
- requests library
# Installation
- Install Python from the original website: https://www.python.org/downloads/
- Install requests library using pip: `pip3 install requests`
# Usage
- Run the scripts by uncommenting the desired scripts to trigger different status codes
- The status code will be printed to the CLI
# Warning!!!
- Do not run the 11. script, it will trigger a 429 status code that is a Too Many Requests error which will block your IP addess.
# Example
- Run the script to trigger a 200 status code
- The output will be: `200`

